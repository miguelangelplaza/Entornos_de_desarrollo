package Test;

/**
 * MatesTest
 */
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.only;

import org.junit.Test;

public class MatesTest {
  public static void main(String[] args) {
    void assertTrue(3 / 1 == 3);
    void assertNull(0);
    

  }
   

  


}